<?php
?>
<p>
    Pour plus d'informations sur les recettes veuillez visiter les sites :
    <br>
    

</p>
<a href="http://www.epicurious.com/recipes/food/views/classic-omelette-15068">http://www.epicurious.com/recipes/food/views/classic-omelette-15068</a><br>
    <a href="http://allrecipes.com/recipe/20586/homemade-vanilla-pudding/">http://allrecipes.com/recipe/20586/homemade-vanilla-pudding/</a>