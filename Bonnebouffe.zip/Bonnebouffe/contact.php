<link href="styles.css" rel="stylesheet" >
<p>Siege : 
<br> 1100 Sainte-Catherine Est, Montreal, Canada
    <br> (514)333-4444
    <br> email : bonnebouffe@manger.com
    <br> Visitez-nous sur nos reseaux sociaux : 
</p>

<a href="https://www.facebook.com"><img src="Images/logoFB.png" width="75px" height="75px"></a>
<a href="https://instagram.com"><img src="Images/logoInsta.jpg" width="75px" height="75px"></a>
<a href="https://twitter.com"><img src="Images/logoTwitter.png" width="75px" height="75px"></a>

<?php
?>